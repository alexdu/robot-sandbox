// A little hackaround (Apple use / in the FILENAME, which doesn't work when following DOS paths)
#include <glu.h>